for i in range(1, 36):
    asw = ""
    if i % 3 == 0 and i % 5 == 0:
        asw = 'FizzBuzz'
    elif i % 3 == 0:
        asw = 'Fizz'
    elif i % 5 == 0:
        asw = 'Buzz'
    else:
        asw = str(i)
asw_user = input(f'O que vem depois de {i}:')
if asw_user.lower() == asw:
    print('A resposta está correta!')
else:
    print(f'A resposta está incorreta, a verdadeira era {asw}!')